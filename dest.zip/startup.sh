#!/bin/sh

java -cp ./lib/tools.jar main/Main ./conf.txt 9090
cd /home/gameboy/

cd ./build/
sh build.sh

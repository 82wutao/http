#!/bin/sh
cd /home/gameboy/build/source/yunwei/webapp
svn update ./ --username wutao --password '#@$@#$dsqe1w123'
rm -fr ./temp/*
